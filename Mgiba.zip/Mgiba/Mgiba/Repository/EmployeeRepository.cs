﻿using Mgiba.Interfaces;
using Mgiba.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mgiba.Repository
{
    public class EmployeeRepository: IEmployeeRepository
    {
        public readonly DataContext _dbContext;

        //inject application DB context
        public EmployeeRepository(DataContext dataContext)
        {
            _dbContext = dataContext;
        }

        public void AddEmployee(Employee employee)
        {
            _dbContext.Add(employee);
            _dbContext.SaveChanges();
        }

        public void AddManager(Employee manager)
        {
            throw new NotImplementedException();
        }

        public bool DeleteEmployee(int id)
        {
            var employee = _dbContext.Employees.FirstOrDefault(e => e.Id == id);

            if (employee == null) return false;

            employee.IsDeleted = true;
            _dbContext.SaveChanges();

            return true;
        }

        public Employee GetEmployeeById(int? id)
        {
            if(id == null)
                return null;

            return _dbContext.Employees.FirstOrDefault(e => e.Id == id);           
        }

        public IEnumerable<Employee> GetEmployees(bool includeDeleted = false)
        {
            if(!includeDeleted)
                return _dbContext.Employees.Where(e => !e.IsDeleted);

            return _dbContext.Employees;
        }

        //Call this from ManagersController
        public Employee GetManager(int id)
        {
            return _dbContext.Employees.FirstOrDefault(e => e.Id == id && e.IsManager);
        }

        //Call this from ManagersController
        public IEnumerable<Employee> GetManagers()
        {
            return _dbContext.Employees.Where(e => e.IsManager);
        }

        public bool RemoveManager(int id)
        {
            var employee = _dbContext.Employees.FirstOrDefault(e => e.Id == id && e.IsManager);

            if (employee == null) return false;

            employee.IsManager = false;
            _dbContext.SaveChanges();

            return true;
        }

        public void UpdateEmployee(int id, Employee employee)
        {
            _dbContext.Employees.FirstOrDefault(e => e.Id == id && e.Status == employee.Status);
            _dbContext.SaveChanges();
        }
        public void CalculateLeave(int id, double requestedDays ) {

           
            var emp = _dbContext.Employees.FirstOrDefault(c => c.Id == id);
            if (emp.LeaveDays > requestedDays && emp != null)
            {
                emp.LeaveDays -= requestedDays;
                _dbContext.SaveChanges();
            }
            
            
        }
    }
}