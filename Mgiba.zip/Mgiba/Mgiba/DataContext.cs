﻿using Mgiba.Models;
using Microsoft.EntityFrameworkCore;

namespace Mgiba
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<Category> Categories { get; set; }
    }
}