﻿using Mgiba.Models;
using System.Collections.Generic;

namespace Mgiba.ModelViews
{
    public class EmployeeModelView
    {
        public IEnumerable<Employee> employees { get; set; }
        public string status { get; set; }
    }
}