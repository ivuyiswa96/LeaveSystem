﻿using Mgiba.Models;
using System.Collections.Generic;

namespace Mgiba.Interfaces
{
    public interface ICategory
    {
        IEnumerable<Category> Categories { get; }
    }
}