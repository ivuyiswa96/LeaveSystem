﻿using Mgiba.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mgiba.Repository
{
    public interface IEmployeeRepository
    {
        void AddEmployee(Employee employee);
        bool DeleteEmployee(int id);
        Employee GetEmployeeById(int? id);
        IEnumerable<Employee> GetEmployees(bool includeDeleted = false);
        void UpdateEmployee(int id, Employee employee);

        void CalculateLeave(int id, double requestedDays);
        void AddManager(Employee manager);
        Employee GetManager(int id);
        IEnumerable<Employee> GetManagers();
        bool RemoveManager(int id);
    }
}
