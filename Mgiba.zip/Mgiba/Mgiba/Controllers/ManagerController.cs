﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Mgiba;
using Mgiba.Models;
using Mgiba.Repository;
using Mgiba.ModelViews;

namespace Mgiba.Controllers
{
    public class ManagerController : Controller
    {

        private readonly IEmployeeRepository _employeeRepository;


        public ManagerController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }



        // GET: Manager
        public async Task<IActionResult> Index()
        {
            ViewBag.LeaveStatuses =  new SelectList(
                new List<SelectListItem>
                {
                        new SelectListItem { Text = Enum.GetName(typeof(LeaveStatus),  LeaveStatus.Submitted), Value = ((int)LeaveStatus.Submitted).ToString()},
                        new SelectListItem { Text = Enum.GetName(typeof(LeaveStatus),  LeaveStatus.Rejected), Value = ((int)LeaveStatus.Rejected).ToString()},
                        new SelectListItem { Text = Enum.GetName(typeof(LeaveStatus),  LeaveStatus.Approved), Value = ((int)LeaveStatus.Approved).ToString()},
                }, "Value", "Text");

            //var employee = _employeeRepository.GetEmployees();
            var model = new EmployeeModelView() { };

            model.employees = _employeeRepository.GetEmployees();
            model.status = null;

            return View(model);
        }

        public ActionResult ChangeLeaveStatus(string Id, string Status)
        {
            var EmId = int.Parse(Id);
            var _status = int.Parse(Status);

            var employee = _employeeRepository.GetEmployeeById(EmId);

            if (_status == 1)
            {
                employee.Status = LeaveStatus.Approved.ToString();
            }
            else if (_status == 2)
            {
                employee.Status = LeaveStatus.Rejected.ToString();
            }
            else if (_status == 3)
            {
                employee.Status = LeaveStatus.Submitted.ToString();
            }

           


            _employeeRepository.UpdateEmployee(EmId, employee);

            return RedirectToAction("Index", "Manager");
        }
      

    
    }
}
