﻿using Mgiba.Models;
using Mgiba.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Mgiba.Controllers
{
    //TODO: Change the Tight Coupling using the Repository
    public class EmployeesController : Controller
    {
        //private readonly DataContext _context;
        private readonly IEmployeeRepository _employeeRepository;

        //public EmployeesController(DataContext context)
        //{
        //    _context = context;
        //}

        public EmployeesController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        // GET: Employees
        public  IActionResult Index()
        {
            return View(_employeeRepository.GetEmployees());
        }

        // GET: Employees/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = _employeeRepository.GetEmployeeById(id);
            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }

        // GET: Employees/Create
        public IActionResult Create()
        {
           // ViewData["CategoryID"] = new SelectList(_employeeRepository.GetEmployees(), "CategoryId", "CategoryId");
            return View(new Employee());
        }

        // POST: Employees/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,FirstName,LastName,IsManager")] Employee employee)
        {
            var rand = new Random();
            var rand2 = new Random();
            var code = new char[] { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'W', 'X', 'Y','Z' };
            if (ModelState.IsValid)
            {
                employee.LeaveDays = 15;
                employee.EmpCode = code[rand2.Next(0,11)].ToString() + rand.Next(0,5000).ToString();
                
                _employeeRepository.AddEmployee(employee);
               
               
                return RedirectToAction(nameof(Index));
            }
          //  ViewData["CategoryID"] = new SelectList(_context.Categories, "CategoryId", "CategoryId", employee.CategoryID);
            return View(employee);
        }

        public ActionResult ApplyLeave(string id, string initialDate,string finalDate )
        {
            var initial = DateTime.Parse(initialDate);
            var final = DateTime.Parse(finalDate);
            int days = (final - initial).Days;
            var Id = int.Parse(id);
            _employeeRepository.CalculateLeave(Id, days);
            return RedirectToAction("Index", "Employee");
        }

      
       // GET: Employees/Edit/5
       public IActionResult Edit(int? id)
       {
           if (id == null)
           {
               return NotFound();
           }

           var employee =  _employeeRepository.GetEmployeeById(id);
           if (employee == null)
           {
               return NotFound();
           }
           return View(employee);
       }


       // POST: Employees/Edit/5
       // To protect from overposting attacks, please enable the specific properties you want to bind to, for
       // more details see http://go.microsoft.com/fwlink/?LinkId=317598.


       // GET: Employees/Delete/5
       public IActionResult Delete(int? id)
       {
           if (id == null)
           {
               return NotFound();
           }

            var employee = _employeeRepository.GetEmployeeById(id);

           if (employee == null)
           {
               return NotFound();
           }

           return View(employee);
       }

       // POST: Employees/Delete/5
       [HttpPost, ActionName("Delete")]
       [ValidateAntiForgeryToken]
       public IActionResult DeleteConfirmed(int id)
       {
            var employee = _employeeRepository.GetEmployeeById(id);

            if (employee == null)
                return NotFound();

            _employeeRepository.DeleteEmployee(id);
            
           return RedirectToAction(nameof(Index));
       }     

       private bool EmployeeExists(int id)
       {
            var employee = _employeeRepository.GetEmployeeById(id);

            if (employee == null) return false; 

            return true;
        }
     
    }
}