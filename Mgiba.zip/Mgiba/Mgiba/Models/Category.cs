﻿namespace Mgiba.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public bool isManager { get; set; }
    }
}