﻿using System.ComponentModel.DataAnnotations;

namespace Mgiba.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double LeaveDays { get; set; }
        public string EmpCode { get; set; }
        public string Status { get; set; }
       
        public LeaveStatus Leavestatus { get; }

        [Display(Name="Is Manager")]
        public bool IsManager { get; set; }

        public bool IsDeleted { get; set; }

        //public  int CategoryID { get; set; }
        //public virtual Category Category { get; set; }
    }
}

public enum LeaveStatus
{
    Submitted,
    Approved,
    Rejected
}