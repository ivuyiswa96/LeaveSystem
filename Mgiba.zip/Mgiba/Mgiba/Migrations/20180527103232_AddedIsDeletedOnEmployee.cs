﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Mgiba.Migrations
{
    public partial class AddedIsDeletedOnEmployee : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Contacts_ContactId",
                table: "Employees");

            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Address_addressId",
                table: "Employees");

            migrationBuilder.DropForeignKey(
                name: "FK_Employees_Employees_employeeId",
                table: "Employees");

            migrationBuilder.DropTable(
                name: "Address");

            migrationBuilder.DropTable(
                name: "Contacts");

            migrationBuilder.DropIndex(
                name: "IX_Employees_ContactId",
                table: "Employees");

            migrationBuilder.DropIndex(
                name: "IX_Employees_addressId",
                table: "Employees");

            migrationBuilder.DropIndex(
                name: "IX_Employees_employeeId",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "ContactId",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "addressId",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "employeeId",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "status",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "isManager",
                table: "Employees",
                newName: "IsManager");

            migrationBuilder.RenameColumn(
                name: "empCode",
                table: "Employees",
                newName: "EmpCode");

            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "Employees",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "Leavestatus",
                table: "Employees",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    isManager = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "Leavestatus",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "IsManager",
                table: "Employees",
                newName: "isManager");

            migrationBuilder.RenameColumn(
                name: "EmpCode",
                table: "Employees",
                newName: "empCode");

            migrationBuilder.AddColumn<int>(
                name: "ContactId",
                table: "Employees",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "addressId",
                table: "Employees",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "employeeId",
                table: "Employees",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "status",
                table: "Employees",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Address",
                columns: table => new
                {
                    addressId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    postal = table.Column<string>(nullable: true),
                    residential = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Address", x => x.addressId);
                });

            migrationBuilder.CreateTable(
                name: "Contacts",
                columns: table => new
                {
                    ContactId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(nullable: true),
                    PhoneNumber = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Contacts", x => x.ContactId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Employees_ContactId",
                table: "Employees",
                column: "ContactId");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_addressId",
                table: "Employees",
                column: "addressId");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_employeeId",
                table: "Employees",
                column: "employeeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Contacts_ContactId",
                table: "Employees",
                column: "ContactId",
                principalTable: "Contacts",
                principalColumn: "ContactId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Address_addressId",
                table: "Employees",
                column: "addressId",
                principalTable: "Address",
                principalColumn: "addressId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Employees_Employees_employeeId",
                table: "Employees",
                column: "employeeId",
                principalTable: "Employees",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
