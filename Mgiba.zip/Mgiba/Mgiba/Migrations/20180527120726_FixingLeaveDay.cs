﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace Mgiba.Migrations
{
    public partial class FixingLeaveDay : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Leavestatus",
                table: "Employees");

            migrationBuilder.AlterColumn<double>(
                name: "LeaveDays",
                table: "Employees",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "LeaveDays",
                table: "Employees",
                nullable: true,
                oldClrType: typeof(double));

            migrationBuilder.AddColumn<int>(
                name: "Leavestatus",
                table: "Employees",
                nullable: false,
                defaultValue: 0);
        }
    }
}
